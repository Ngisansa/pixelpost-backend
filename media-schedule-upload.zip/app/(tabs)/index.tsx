import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import { Image } from 'expo-image';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../context/AuthContext';
import { useApp } from '../context/AppContext';
import { COLORS, SIZES, SHADOWS, IMAGES } from '../constants/theme';
import { ANALYTICS_DATA } from '../constants/data';
import PostCard from '../components/PostCard';

const { width } = Dimensions.get('window');

export default function HomeScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { posts, connectedAccounts, credits, notifications, unreadCount } = useApp();

  const recentPosts = posts.slice(0, 3);
  const scheduledPosts = posts.filter(p => p.status === 'scheduled');
  const publishedPosts = posts.filter(p => p.status === 'published');

  const quickStats = [
    {
      icon: 'document-text',
      label: 'Total Posts',
      value: posts.length.toString(),
      color: COLORS.primary,
    },
    {
      icon: 'time',
      label: 'Scheduled',
      value: scheduledPosts.length.toString(),
      color: COLORS.info,
    },
    {
      icon: 'checkmark-circle',
      label: 'Published',
      value: publishedPosts.length.toString(),
      color: COLORS.success,
    },
    {
      icon: 'flash',
      label: 'Credits',
      value: credits.toString(),
      color: COLORS.warning,
    },
  ];

  return (
    <View style={styles.container}>
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, { paddingBottom: insets.bottom + 100 }]}
        showsVerticalScrollIndicator={false}
      >
        {/* Welcome Section */}
        <View style={styles.welcomeSection}>
          <View style={styles.welcomeLeft}>
            <Text style={styles.greeting}>
              Welcome back,{'\n'}
              <Text style={styles.userName}>{user?.name || 'Creator'}</Text>
            </Text>
            <Text style={styles.subtitle}>
              {scheduledPosts.length > 0
                ? `You have ${scheduledPosts.length} posts scheduled`
                : 'No posts scheduled yet'}
            </Text>
          </View>
          <TouchableOpacity
            style={styles.notificationButton}
            onPress={() => router.push('/profile')}
          >
            <Ionicons name="notifications" size={24} color={COLORS.text} />
            {unreadCount > 0 && (
              <View style={styles.notificationBadge}>
                <Text style={styles.notificationBadgeText}>{unreadCount}</Text>
              </View>
            )}
          </TouchableOpacity>
        </View>

        {/* Quick Stats */}
        <View style={styles.statsGrid}>
          {quickStats.map((stat, index) => (
            <View key={index} style={styles.statCard}>
              <View style={[styles.statIcon, { backgroundColor: stat.color + '20' }]}>
                <Ionicons
                  name={stat.icon as keyof typeof Ionicons.glyphMap}
                  size={20}
                  color={stat.color}
                />
              </View>
              <Text style={styles.statValue}>{stat.value}</Text>
              <Text style={styles.statLabel}>{stat.label}</Text>
            </View>
          ))}
        </View>

        {/* Quick Actions */}
        <View style={styles.quickActions}>
          <TouchableOpacity
            style={[styles.actionButton, { backgroundColor: COLORS.primary }]}
            onPress={() => router.push('/create-post')}
          >
            <Ionicons name="add-circle" size={24} color={COLORS.white} />
            <Text style={styles.actionButtonText}>Create Post</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.actionButton, { backgroundColor: COLORS.secondary }]}
            onPress={() => router.push('/connect-accounts')}
          >
            <Ionicons name="link" size={24} color={COLORS.white} />
            <Text style={styles.actionButtonText}>Connect</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.actionButton, { backgroundColor: COLORS.accent }]}
            onPress={() => router.push('/(tabs)/analytics')}
          >
            <Ionicons name="analytics" size={24} color={COLORS.white} />
            <Text style={styles.actionButtonText}>Analytics</Text>
          </TouchableOpacity>
        </View>

        {/* Connected Accounts */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Connected Accounts</Text>
            <TouchableOpacity onPress={() => router.push('/connect-accounts')}>
              <Text style={styles.seeAllText}>Manage</Text>
            </TouchableOpacity>
          </View>
          {connectedAccounts.length > 0 ? (
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.accountsScroll}
            >
              {connectedAccounts.map((account, index) => (
                <View key={index} style={styles.accountChip}>
                  <Ionicons
                    name={`logo-${account.platform}` as keyof typeof Ionicons.glyphMap}
                    size={18}
                    color={COLORS.text}
                  />
                  <Text style={styles.accountChipText}>@{account.username}</Text>
                </View>
              ))}
            </ScrollView>
          ) : (
            <TouchableOpacity
              style={styles.emptyAccounts}
              onPress={() => router.push('/connect-accounts')}
            >
              <Ionicons name="add-circle-outline" size={32} color={COLORS.textMuted} />
              <Text style={styles.emptyAccountsText}>Connect your first account</Text>
            </TouchableOpacity>
          )}
        </View>

        {/* Performance Overview */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Performance Overview</Text>
            <TouchableOpacity onPress={() => router.push('/(tabs)/analytics')}>
              <Text style={styles.seeAllText}>View All</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.performanceCard}>
            <View style={styles.performanceRow}>
              <View style={styles.performanceItem}>
                <Text style={styles.performanceValue}>
                  {ANALYTICS_DATA.overview.totalEngagement.toLocaleString()}
                </Text>
                <Text style={styles.performanceLabel}>Total Engagement</Text>
              </View>
              <View style={styles.performanceDivider} />
              <View style={styles.performanceItem}>
                <Text style={styles.performanceValue}>
                  {ANALYTICS_DATA.overview.totalReach.toLocaleString()}
                </Text>
                <Text style={styles.performanceLabel}>Total Reach</Text>
              </View>
            </View>
            <View style={styles.growthBadge}>
              <Ionicons name="trending-up" size={16} color={COLORS.success} />
              <Text style={styles.growthText}>
                +{ANALYTICS_DATA.overview.growthRate}% this month
              </Text>
            </View>
          </View>
        </View>

        {/* Recent Posts */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Recent Posts</Text>
            <TouchableOpacity onPress={() => router.push('/(tabs)/schedule')}>
              <Text style={styles.seeAllText}>See All</Text>
            </TouchableOpacity>
          </View>
          {recentPosts.length > 0 ? (
            recentPosts.map((post) => (
              <PostCard
                key={post.id}
                post={post}
                onPress={() => {}}
              />
            ))
          ) : (
            <View style={styles.emptyPosts}>
              <Ionicons name="images-outline" size={48} color={COLORS.textMuted} />
              <Text style={styles.emptyPostsTitle}>No posts yet</Text>
              <Text style={styles.emptyPostsText}>
                Create your first post to get started
              </Text>
              <TouchableOpacity
                style={styles.createFirstButton}
                onPress={() => router.push('/create-post')}
              >
                <Text style={styles.createFirstButtonText}>Create Post</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>

        {/* Upgrade Banner */}
        {user?.subscription === 'free' && (
          <TouchableOpacity
            style={styles.upgradeBanner}
            onPress={() => router.push('/subscription')}
          >
            <View style={styles.upgradeContent}>
              <Ionicons name="rocket" size={32} color={COLORS.white} />
              <View style={styles.upgradeText}>
                <Text style={styles.upgradeTitle}>Upgrade to Pro</Text>
                <Text style={styles.upgradeSubtitle}>
                  Unlock unlimited posts & advanced features
                </Text>
              </View>
            </View>
            <Ionicons name="chevron-forward" size={24} color={COLORS.white} />
          </TouchableOpacity>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  welcomeSection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 24,
  },
  welcomeLeft: {
    flex: 1,
  },
  greeting: {
    fontSize: 16,
    color: COLORS.textSecondary,
    lineHeight: 24,
  },
  userName: {
    fontSize: 24,
    fontWeight: '700',
    color: COLORS.text,
  },
  subtitle: {
    fontSize: 14,
    color: COLORS.textMuted,
    marginTop: 4,
  },
  notificationButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: COLORS.backgroundCard,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  notificationBadge: {
    position: 'absolute',
    top: 8,
    right: 8,
    minWidth: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: COLORS.error,
    alignItems: 'center',
    justifyContent: 'center',
  },
  notificationBadgeText: {
    fontSize: 10,
    fontWeight: '700',
    color: COLORS.white,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  statCard: {
    width: (width - 52) / 2,
    backgroundColor: COLORS.backgroundCard,
    borderRadius: SIZES.radius,
    padding: 16,
    marginBottom: 12,
    ...SHADOWS.small,
  },
  statIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  statValue: {
    fontSize: 24,
    fontWeight: '700',
    color: COLORS.text,
  },
  statLabel: {
    fontSize: 13,
    color: COLORS.textMuted,
    marginTop: 4,
  },
  quickActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    borderRadius: SIZES.radius,
    marginHorizontal: 4,
    ...SHADOWS.small,
  },
  actionButtonText: {
    fontSize: 13,
    fontWeight: '600',
    color: COLORS.white,
    marginLeft: 6,
  },
  section: {
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: COLORS.text,
  },
  seeAllText: {
    fontSize: 14,
    fontWeight: '500',
    color: COLORS.primary,
  },
  accountsScroll: {
    paddingRight: 20,
  },
  accountChip: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.backgroundCard,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 20,
    marginRight: 10,
  },
  accountChipText: {
    fontSize: 13,
    color: COLORS.text,
    marginLeft: 8,
  },
  emptyAccounts: {
    backgroundColor: COLORS.backgroundCard,
    borderRadius: SIZES.radius,
    padding: 24,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: COLORS.border,
    borderStyle: 'dashed',
  },
  emptyAccountsText: {
    fontSize: 14,
    color: COLORS.textMuted,
    marginTop: 8,
  },
  performanceCard: {
    backgroundColor: COLORS.backgroundCard,
    borderRadius: SIZES.radius,
    padding: 20,
    ...SHADOWS.small,
  },
  performanceRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  performanceItem: {
    flex: 1,
    alignItems: 'center',
  },
  performanceValue: {
    fontSize: 24,
    fontWeight: '700',
    color: COLORS.text,
  },
  performanceLabel: {
    fontSize: 13,
    color: COLORS.textMuted,
    marginTop: 4,
  },
  performanceDivider: {
    width: 1,
    height: 40,
    backgroundColor: COLORS.border,
    marginHorizontal: 16,
  },
  growthBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: COLORS.border,
  },
  growthText: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.success,
    marginLeft: 6,
  },
  emptyPosts: {
    backgroundColor: COLORS.backgroundCard,
    borderRadius: SIZES.radius,
    padding: 40,
    alignItems: 'center',
  },
  emptyPostsTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: COLORS.text,
    marginTop: 16,
  },
  emptyPostsText: {
    fontSize: 14,
    color: COLORS.textMuted,
    marginTop: 8,
    textAlign: 'center',
  },
  createFirstButton: {
    marginTop: 20,
    backgroundColor: COLORS.primary,
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: SIZES.radius,
  },
  createFirstButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.white,
  },
  upgradeBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: COLORS.primary,
    borderRadius: SIZES.radius,
    padding: 20,
    marginBottom: 24,
    ...SHADOWS.medium,
  },
  upgradeContent: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  upgradeText: {
    marginLeft: 16,
    flex: 1,
  },
  upgradeTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: COLORS.white,
  },
  upgradeSubtitle: {
    fontSize: 13,
    color: COLORS.white,
    opacity: 0.9,
    marginTop: 4,
  },
});
