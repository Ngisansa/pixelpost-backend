import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { COLORS, SIZES, SHADOWS } from '../constants/theme';
import { ANALYTICS_DATA } from '../constants/data';

const { width } = Dimensions.get('window');

type TimeRange = '7d' | '30d' | '90d';

export default function AnalyticsScreen() {
  const insets = useSafeAreaInsets();
  const [timeRange, setTimeRange] = useState<TimeRange>('7d');

  const timeRanges: { key: TimeRange; label: string }[] = [
    { key: '7d', label: '7 Days' },
    { key: '30d', label: '30 Days' },
    { key: '90d', label: '90 Days' },
  ];

  const overviewCards = [
    {
      icon: 'document-text',
      label: 'Total Posts',
      value: ANALYTICS_DATA.overview.totalPosts,
      change: '+12',
      positive: true,
      color: COLORS.primary,
    },
    {
      icon: 'heart',
      label: 'Engagement',
      value: ANALYTICS_DATA.overview.totalEngagement.toLocaleString(),
      change: '+8.5%',
      positive: true,
      color: COLORS.secondary,
    },
    {
      icon: 'eye',
      label: 'Total Reach',
      value: ANALYTICS_DATA.overview.totalReach.toLocaleString(),
      change: '+15.2%',
      positive: true,
      color: COLORS.accent,
    },
    {
      icon: 'trending-up',
      label: 'Growth Rate',
      value: `${ANALYTICS_DATA.overview.growthRate}%`,
      change: '+2.3%',
      positive: true,
      color: COLORS.success,
    },
  ];

  const maxEngagement = Math.max(...ANALYTICS_DATA.weeklyStats.map(s => s.engagement));

  return (
    <View style={styles.container}>
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingBottom: insets.bottom + 100 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {/* Time Range Selector */}
        <View style={styles.timeRangeContainer}>
          {timeRanges.map((range) => (
            <TouchableOpacity
              key={range.key}
              style={[
                styles.timeRangeButton,
                timeRange === range.key && styles.timeRangeButtonActive,
              ]}
              onPress={() => setTimeRange(range.key)}
            >
              <Text
                style={[
                  styles.timeRangeText,
                  timeRange === range.key && styles.timeRangeTextActive,
                ]}
              >
                {range.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Overview Cards */}
        <View style={styles.overviewGrid}>
          {overviewCards.map((card, index) => (
            <View key={index} style={styles.overviewCard}>
              <View style={[styles.cardIcon, { backgroundColor: card.color + '20' }]}>
                <Ionicons
                  name={card.icon as keyof typeof Ionicons.glyphMap}
                  size={20}
                  color={card.color}
                />
              </View>
              <Text style={styles.cardValue}>{card.value}</Text>
              <Text style={styles.cardLabel}>{card.label}</Text>
              <View style={styles.cardChange}>
                <Ionicons
                  name={card.positive ? 'arrow-up' : 'arrow-down'}
                  size={12}
                  color={card.positive ? COLORS.success : COLORS.error}
                />
                <Text
                  style={[
                    styles.cardChangeText,
                    { color: card.positive ? COLORS.success : COLORS.error },
                  ]}
                >
                  {card.change}
                </Text>
              </View>
            </View>
          ))}
        </View>

        {/* Engagement Chart */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Weekly Engagement</Text>
          <View style={styles.chartContainer}>
            <View style={styles.chartBars}>
              {ANALYTICS_DATA.weeklyStats.map((stat, index) => (
                <View key={index} style={styles.chartBarContainer}>
                  <View
                    style={[
                      styles.chartBar,
                      {
                        height: (stat.engagement / maxEngagement) * 120,
                        backgroundColor:
                          index === ANALYTICS_DATA.weeklyStats.length - 2
                            ? COLORS.primary
                            : COLORS.primary + '40',
                      },
                    ]}
                  />
                  <Text style={styles.chartLabel}>{stat.day}</Text>
                </View>
              ))}
            </View>
          </View>
        </View>

        {/* Platform Performance */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Platform Performance</Text>
          {ANALYTICS_DATA.platformStats.map((platform, index) => (
            <View key={index} style={styles.platformCard}>
              <View style={styles.platformHeader}>
                <View style={styles.platformInfo}>
                  <Ionicons
                    name={`logo-${platform.platform.toLowerCase()}` as keyof typeof Ionicons.glyphMap}
                    size={24}
                    color={COLORS.text}
                  />
                  <Text style={styles.platformName}>{platform.platform}</Text>
                </View>
                <View style={styles.platformStats}>
                  <Text style={styles.platformFollowers}>
                    {platform.followers.toLocaleString()} followers
                  </Text>
                </View>
              </View>
              <View style={styles.platformMetrics}>
                <View style={styles.metric}>
                  <Text style={styles.metricValue}>{platform.engagement}%</Text>
                  <Text style={styles.metricLabel}>Engagement</Text>
                </View>
                <View style={styles.metric}>
                  <Text style={styles.metricValue}>{platform.posts}</Text>
                  <Text style={styles.metricLabel}>Posts</Text>
                </View>
                <View style={styles.metric}>
                  <Text style={styles.metricValue}>
                    {Math.round(platform.followers * (platform.engagement / 100))}
                  </Text>
                  <Text style={styles.metricLabel}>Avg. Reach</Text>
                </View>
              </View>
              <View style={styles.progressBar}>
                <View
                  style={[
                    styles.progressFill,
                    { width: `${platform.engagement * 10}%` },
                  ]}
                />
              </View>
            </View>
          ))}
        </View>

        {/* Best Posting Times */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Best Posting Times</Text>
          <View style={styles.bestTimesContainer}>
            {ANALYTICS_DATA.bestTimes.map((time, index) => (
              <View key={index} style={styles.bestTimeCard}>
                <View style={styles.bestTimeDay}>
                  <Ionicons name="calendar-outline" size={16} color={COLORS.primary} />
                  <Text style={styles.bestTimeDayText}>{time.day}</Text>
                </View>
                <Text style={styles.bestTimeValue}>{time.time}</Text>
                <View
                  style={[
                    styles.engagementBadge,
                    {
                      backgroundColor:
                        time.engagement === 'Very High'
                          ? COLORS.success + '20'
                          : COLORS.info + '20',
                    },
                  ]}
                >
                  <Text
                    style={[
                      styles.engagementBadgeText,
                      {
                        color:
                          time.engagement === 'Very High'
                            ? COLORS.success
                            : COLORS.info,
                      },
                    ]}
                  >
                    {time.engagement}
                  </Text>
                </View>
              </View>
            ))}
          </View>
        </View>

        {/* Export Section */}
        <View style={styles.exportSection}>
          <Text style={styles.exportTitle}>Export Reports</Text>
          <Text style={styles.exportSubtitle}>
            Download detailed analytics reports
          </Text>
          <View style={styles.exportButtons}>
            <TouchableOpacity style={styles.exportButton}>
              <Ionicons name="document-text" size={20} color={COLORS.primary} />
              <Text style={styles.exportButtonText}>PDF Report</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.exportButton}>
              <Ionicons name="grid" size={20} color={COLORS.success} />
              <Text style={styles.exportButtonText}>CSV Export</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  timeRangeContainer: {
    flexDirection: 'row',
    backgroundColor: COLORS.backgroundCard,
    borderRadius: SIZES.radius,
    padding: 4,
    marginBottom: 24,
  },
  timeRangeButton: {
    flex: 1,
    paddingVertical: 10,
    alignItems: 'center',
    borderRadius: SIZES.radiusSmall,
  },
  timeRangeButtonActive: {
    backgroundColor: COLORS.primary,
  },
  timeRangeText: {
    fontSize: 14,
    fontWeight: '500',
    color: COLORS.textMuted,
  },
  timeRangeTextActive: {
    color: COLORS.white,
  },
  overviewGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  overviewCard: {
    width: (width - 52) / 2,
    backgroundColor: COLORS.backgroundCard,
    borderRadius: SIZES.radius,
    padding: 16,
    marginBottom: 12,
    ...SHADOWS.small,
  },
  cardIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  cardValue: {
    fontSize: 24,
    fontWeight: '700',
    color: COLORS.text,
  },
  cardLabel: {
    fontSize: 13,
    color: COLORS.textMuted,
    marginTop: 4,
  },
  cardChange: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
  },
  cardChangeText: {
    fontSize: 12,
    fontWeight: '600',
    marginLeft: 4,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: COLORS.text,
    marginBottom: 16,
  },
  chartContainer: {
    backgroundColor: COLORS.backgroundCard,
    borderRadius: SIZES.radius,
    padding: 20,
    ...SHADOWS.small,
  },
  chartBars: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    height: 150,
  },
  chartBarContainer: {
    alignItems: 'center',
    flex: 1,
  },
  chartBar: {
    width: 24,
    borderRadius: 4,
    marginBottom: 8,
  },
  chartLabel: {
    fontSize: 11,
    color: COLORS.textMuted,
  },
  platformCard: {
    backgroundColor: COLORS.backgroundCard,
    borderRadius: SIZES.radius,
    padding: 16,
    marginBottom: 12,
    ...SHADOWS.small,
  },
  platformHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  platformInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  platformName: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.text,
    marginLeft: 12,
  },
  platformStats: {},
  platformFollowers: {
    fontSize: 13,
    color: COLORS.textSecondary,
  },
  platformMetrics: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  metric: {
    alignItems: 'center',
  },
  metricValue: {
    fontSize: 18,
    fontWeight: '700',
    color: COLORS.text,
  },
  metricLabel: {
    fontSize: 12,
    color: COLORS.textMuted,
    marginTop: 4,
  },
  progressBar: {
    height: 4,
    backgroundColor: COLORS.backgroundInput,
    borderRadius: 2,
  },
  progressFill: {
    height: '100%',
    backgroundColor: COLORS.primary,
    borderRadius: 2,
  },
  bestTimesContainer: {},
  bestTimeCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.backgroundCard,
    borderRadius: SIZES.radius,
    padding: 16,
    marginBottom: 10,
  },
  bestTimeDay: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  bestTimeDayText: {
    fontSize: 14,
    color: COLORS.text,
    marginLeft: 8,
  },
  bestTimeValue: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.text,
    marginRight: 12,
  },
  engagementBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  engagementBadgeText: {
    fontSize: 12,
    fontWeight: '600',
  },
  exportSection: {
    backgroundColor: COLORS.backgroundCard,
    borderRadius: SIZES.radius,
    padding: 20,
    alignItems: 'center',
  },
  exportTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: COLORS.text,
    marginBottom: 8,
  },
  exportSubtitle: {
    fontSize: 14,
    color: COLORS.textMuted,
    marginBottom: 20,
  },
  exportButtons: {
    flexDirection: 'row',
    justifyContent: 'center',
  },
  exportButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.backgroundInput,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: SIZES.radius,
    marginHorizontal: 8,
  },
  exportButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: COLORS.text,
    marginLeft: 8,
  },
});
