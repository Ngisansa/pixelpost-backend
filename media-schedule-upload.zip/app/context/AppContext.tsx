import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { SAMPLE_POSTS, SAMPLE_NOTIFICATIONS, SOCIAL_PLATFORMS } from '../constants/data';
import { 
  getConnectedAccounts as getStoredAccounts, 
  ConnectedAccount as StoredAccount 
} from '../services/secureStorage';

// Types
export interface Post {
  id: string;
  image: string;
  caption: string;
  platforms: string[];
  scheduledAt: string | null;
  status: 'draft' | 'scheduled' | 'published' | 'failed';
  likes: number;
  comments: number;
  shares: number;
}

export interface Notification {
  id: string;
  type: string;
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
}

export interface ConnectedAccount {
  id: string;
  platform: string;
  username: string;
  avatar?: string;
  connectedAt: string;
  accessToken?: string;
}

interface AppContextType {
  // Posts
  posts: Post[];
  addPost: (post: Omit<Post, 'id'>) => void;
  updatePost: (id: string, updates: Partial<Post>) => void;
  deletePost: (id: string) => void;
  
  // Connected Accounts
  connectedAccounts: ConnectedAccount[];
  connectAccount: (platform: string, username: string) => Promise<boolean>;
  disconnectAccount: (id: string) => void;
  refreshConnectedAccounts: () => Promise<void>;
  
  // Notifications
  notifications: Notification[];
  markNotificationRead: (id: string) => void;
  clearNotifications: () => void;
  unreadCount: number;
  
  // Credits & Subscription
  credits: number;
  addCredits: (amount: number) => void;
  useCredit: () => boolean;
  
  // UI State
  isDarkMode: boolean;
  toggleDarkMode: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const POSTS_KEY = '@pixelpost_posts';
const ACCOUNTS_KEY = '@pixelpost_accounts';
const NOTIFICATIONS_KEY = '@pixelpost_notifications';
const CREDITS_KEY = '@pixelpost_credits';

export function AppProvider({ children }: { children: ReactNode }) {
  const [posts, setPosts] = useState<Post[]>(SAMPLE_POSTS);
  const [connectedAccounts, setConnectedAccounts] = useState<ConnectedAccount[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>(SAMPLE_NOTIFICATIONS);
  const [credits, setCredits] = useState(5);
  const [isDarkMode, setIsDarkMode] = useState(true);

  // Load data from storage
  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [storedPosts, storedNotifications, storedCredits] = await Promise.all([
        AsyncStorage.getItem(POSTS_KEY),
        AsyncStorage.getItem(NOTIFICATIONS_KEY),
        AsyncStorage.getItem(CREDITS_KEY),
      ]);

      if (storedPosts) setPosts(JSON.parse(storedPosts));
      if (storedNotifications) setNotifications(JSON.parse(storedNotifications));
      if (storedCredits) setCredits(JSON.parse(storedCredits));

      // Load securely stored accounts
      await refreshConnectedAccounts();
    } catch (error) {
      console.error('Error loading data:', error);
    }
  };

  // Refresh connected accounts from secure storage
  const refreshConnectedAccounts = async () => {
    try {
      const storedAccounts = await getStoredAccounts();
      const accounts: ConnectedAccount[] = storedAccounts.map(acc => ({
        id: acc.id,
        platform: acc.platform,
        username: acc.username,
        avatar: acc.profilePicture,
        connectedAt: acc.connectedAt,
      }));
      setConnectedAccounts(accounts);
    } catch (error) {
      console.error('Error refreshing connected accounts:', error);
    }
  };

  // Posts functions
  const addPost = (post: Omit<Post, 'id'>) => {
    const newPost: Post = {
      ...post,
      id: Math.random().toString(36).substr(2, 9),
    };
    const updatedPosts = [newPost, ...posts];
    setPosts(updatedPosts);
    AsyncStorage.setItem(POSTS_KEY, JSON.stringify(updatedPosts));
  };

  const updatePost = (id: string, updates: Partial<Post>) => {
    const updatedPosts = posts.map(post =>
      post.id === id ? { ...post, ...updates } : post
    );
    setPosts(updatedPosts);
    AsyncStorage.setItem(POSTS_KEY, JSON.stringify(updatedPosts));
  };

  const deletePost = (id: string) => {
    const updatedPosts = posts.filter(post => post.id !== id);
    setPosts(updatedPosts);
    AsyncStorage.setItem(POSTS_KEY, JSON.stringify(updatedPosts));
  };

  // Connected Accounts functions
  const connectAccount = async (platform: string, username: string): Promise<boolean> => {
    try {
      const platformInfo = SOCIAL_PLATFORMS.find(p => p.id === platform);
      if (!platformInfo) return false;

      const newAccount: ConnectedAccount = {
        id: Math.random().toString(36).substr(2, 9),
        platform,
        username,
        connectedAt: new Date().toISOString(),
      };

      const updatedAccounts = [...connectedAccounts.filter(a => a.platform !== platform), newAccount];
      setConnectedAccounts(updatedAccounts);

      return true;
    } catch (error) {
      console.error('Error connecting account:', error);
      return false;
    }
  };

  const disconnectAccount = (id: string) => {
    const updatedAccounts = connectedAccounts.filter(acc => acc.id !== id);
    setConnectedAccounts(updatedAccounts);
  };

  // Notifications functions
  const markNotificationRead = (id: string) => {
    const updatedNotifications = notifications.map(notif =>
      notif.id === id ? { ...notif, read: true } : notif
    );
    setNotifications(updatedNotifications);
    AsyncStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify(updatedNotifications));
  };

  const clearNotifications = () => {
    setNotifications([]);
    AsyncStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify([]));
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  // Credits functions
  const addCredits = (amount: number) => {
    const newCredits = credits + amount;
    setCredits(newCredits);
    AsyncStorage.setItem(CREDITS_KEY, JSON.stringify(newCredits));
  };

  const useCredit = (): boolean => {
    if (credits > 0) {
      const newCredits = credits - 1;
      setCredits(newCredits);
      AsyncStorage.setItem(CREDITS_KEY, JSON.stringify(newCredits));
      return true;
    }
    return false;
  };

  // UI functions
  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
  };

  return (
    <AppContext.Provider
      value={{
        posts,
        addPost,
        updatePost,
        deletePost,
        connectedAccounts,
        connectAccount,
        disconnectAccount,
        refreshConnectedAccounts,
        notifications,
        markNotificationRead,
        clearNotifications,
        unreadCount,
        credits,
        addCredits,
        useCredit,
        isDarkMode,
        toggleDarkMode,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}

export default AppContext;
