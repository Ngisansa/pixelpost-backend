import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  Platform,
} from 'react-native';
import { Image } from 'expo-image';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as ImagePicker from 'expo-image-picker';
import { useApp } from '../context/AppContext';
import { COLORS, SIZES, SHADOWS, IMAGES } from '../constants/theme';
import { SOCIAL_PLATFORMS, HASHTAG_SUGGESTIONS } from '../constants/data';
import Input from '../components/Input';
import Button from '../components/Button';

export default function CreateScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { addPost, connectedAccounts, credits, useCredit } = useApp();

  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [caption, setCaption] = useState('');
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([]);
  const [scheduledDate, setScheduledDate] = useState<Date | null>(null);
  const [isScheduling, setIsScheduling] = useState(false);
  const [showHashtags, setShowHashtags] = useState(false);

  const connectedPlatformIds = connectedAccounts.map(acc => acc.platform);

  const pickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    
    if (status !== 'granted') {
      Alert.alert('Permission Required', 'Please allow access to your photo library');
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8,
    });

    if (!result.canceled && result.assets[0]) {
      setSelectedImage(result.assets[0].uri);
    }
  };

  const takePhoto = async () => {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    
    if (status !== 'granted') {
      Alert.alert('Permission Required', 'Please allow access to your camera');
      return;
    }

    const result = await ImagePicker.launchCameraAsync({
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8,
    });

    if (!result.canceled && result.assets[0]) {
      setSelectedImage(result.assets[0].uri);
    }
  };

  const togglePlatform = (platformId: string) => {
    if (selectedPlatforms.includes(platformId)) {
      setSelectedPlatforms(selectedPlatforms.filter(id => id !== platformId));
    } else {
      setSelectedPlatforms([...selectedPlatforms, platformId]);
    }
  };

  const addHashtag = (hashtag: string) => {
    if (!caption.includes(hashtag)) {
      setCaption(caption + (caption ? ' ' : '') + hashtag);
    }
  };

  const handlePost = () => {
    if (!selectedImage) {
      Alert.alert('Missing Image', 'Please select an image or video to post');
      return;
    }

    if (!caption.trim()) {
      Alert.alert('Missing Caption', 'Please add a caption for your post');
      return;
    }

    if (selectedPlatforms.length === 0) {
      Alert.alert('No Platforms Selected', 'Please select at least one platform to post to');
      return;
    }

    // Check credits
    if (credits <= 0) {
      Alert.alert(
        'No Credits',
        'You need credits to post. Would you like to upgrade?',
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Upgrade', onPress: () => router.push('/subscription') },
        ]
      );
      return;
    }

    // Use a credit
    useCredit();

    // Add the post
    addPost({
      image: selectedImage,
      caption: caption.trim(),
      platforms: selectedPlatforms,
      scheduledAt: scheduledDate?.toISOString() || null,
      status: scheduledDate ? 'scheduled' : 'published',
      likes: 0,
      comments: 0,
      shares: 0,
    });

    Alert.alert(
      'Success!',
      scheduledDate ? 'Your post has been scheduled!' : 'Your post has been published!',
      [{ text: 'OK', onPress: () => router.push('/(tabs)/schedule') }]
    );

    // Reset form
    setSelectedImage(null);
    setCaption('');
    setSelectedPlatforms([]);
    setScheduledDate(null);
  };

  const handleSaveDraft = () => {
    if (!selectedImage && !caption.trim()) {
      Alert.alert('Empty Draft', 'Please add content before saving as draft');
      return;
    }

    addPost({
      image: selectedImage || IMAGES.samplePosts[0],
      caption: caption.trim() || 'Draft post',
      platforms: selectedPlatforms,
      scheduledAt: null,
      status: 'draft',
      likes: 0,
      comments: 0,
      shares: 0,
    });

    Alert.alert('Draft Saved', 'Your draft has been saved successfully');
    
    setSelectedImage(null);
    setCaption('');
    setSelectedPlatforms([]);
  };

  return (
    <View style={styles.container}>
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingBottom: insets.bottom + 100 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {/* Media Selection */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Media</Text>
          {selectedImage ? (
            <View style={styles.selectedImageContainer}>
              <Image
                source={{ uri: selectedImage }}
                style={styles.selectedImage}
                contentFit="cover"
              />
              <TouchableOpacity
                style={styles.removeImageButton}
                onPress={() => setSelectedImage(null)}
              >
                <Ionicons name="close-circle" size={28} color={COLORS.error} />
              </TouchableOpacity>
            </View>
          ) : (
            <View style={styles.mediaButtons}>
              <TouchableOpacity style={styles.mediaButton} onPress={pickImage}>
                <View style={styles.mediaButtonIcon}>
                  <Ionicons name="images" size={32} color={COLORS.primary} />
                </View>
                <Text style={styles.mediaButtonText}>Gallery</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.mediaButton} onPress={takePhoto}>
                <View style={styles.mediaButtonIcon}>
                  <Ionicons name="camera" size={32} color={COLORS.secondary} />
                </View>
                <Text style={styles.mediaButtonText}>Camera</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>

        {/* Caption */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Caption</Text>
          <Input
            placeholder="Write your caption..."
            value={caption}
            onChangeText={setCaption}
            multiline
            numberOfLines={4}
            maxLength={2200}
          />
          
          {/* Hashtag Suggestions */}
          <TouchableOpacity
            style={styles.hashtagToggle}
            onPress={() => setShowHashtags(!showHashtags)}
          >
            <Ionicons name="pricetag" size={18} color={COLORS.primary} />
            <Text style={styles.hashtagToggleText}>Hashtag Suggestions</Text>
            <Ionicons
              name={showHashtags ? 'chevron-up' : 'chevron-down'}
              size={18}
              color={COLORS.textMuted}
            />
          </TouchableOpacity>
          
          {showHashtags && (
            <View style={styles.hashtagsContainer}>
              {Object.entries(HASHTAG_SUGGESTIONS).map(([category, tags]) => (
                <View key={category} style={styles.hashtagCategory}>
                  <Text style={styles.hashtagCategoryTitle}>
                    {category.charAt(0).toUpperCase() + category.slice(1)}
                  </Text>
                  <View style={styles.hashtagsList}>
                    {tags.slice(0, 4).map((tag, index) => (
                      <TouchableOpacity
                        key={index}
                        style={styles.hashtagChip}
                        onPress={() => addHashtag(tag)}
                      >
                        <Text style={styles.hashtagChipText}>{tag}</Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>
              ))}
            </View>
          )}
        </View>

        {/* Platform Selection */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Post To</Text>
          {connectedPlatformIds.length > 0 ? (
            <View style={styles.platformsGrid}>
              {SOCIAL_PLATFORMS.filter(p => connectedPlatformIds.includes(p.id)).map((platform) => (
                <TouchableOpacity
                  key={platform.id}
                  style={[
                    styles.platformCard,
                    selectedPlatforms.includes(platform.id) && styles.platformCardSelected,
                  ]}
                  onPress={() => togglePlatform(platform.id)}
                >
                  <View
                    style={[
                      styles.platformIconContainer,
                      { backgroundColor: platform.color + '20' },
                    ]}
                  >
                    <Ionicons
                      name={platform.icon as keyof typeof Ionicons.glyphMap}
                      size={24}
                      color={platform.color}
                    />
                  </View>
                  <Text style={styles.platformName}>{platform.name}</Text>
                  {selectedPlatforms.includes(platform.id) && (
                    <View style={styles.checkmark}>
                      <Ionicons name="checkmark-circle" size={20} color={COLORS.success} />
                    </View>
                  )}
                </TouchableOpacity>
              ))}
            </View>
          ) : (
            <TouchableOpacity
              style={styles.connectPrompt}
              onPress={() => router.push('/connect-accounts')}
            >
              <Ionicons name="link" size={24} color={COLORS.primary} />
              <Text style={styles.connectPromptText}>Connect your social accounts first</Text>
              <Ionicons name="chevron-forward" size={20} color={COLORS.textMuted} />
            </TouchableOpacity>
          )}
        </View>

        {/* Schedule Toggle */}
        <View style={styles.section}>
          <TouchableOpacity
            style={styles.scheduleToggle}
            onPress={() => setIsScheduling(!isScheduling)}
          >
            <View style={styles.scheduleToggleLeft}>
              <Ionicons
                name="calendar"
                size={24}
                color={isScheduling ? COLORS.primary : COLORS.textMuted}
              />
              <Text style={styles.scheduleToggleText}>Schedule for later</Text>
            </View>
            <View
              style={[
                styles.toggle,
                isScheduling && styles.toggleActive,
              ]}
            >
              <View
                style={[
                  styles.toggleKnob,
                  isScheduling && styles.toggleKnobActive,
                ]}
              />
            </View>
          </TouchableOpacity>
          
          {isScheduling && (
            <View style={styles.schedulePicker}>
              <Text style={styles.scheduleNote}>
                Scheduling will be available in the full version. For now, posts will be saved as scheduled.
              </Text>
            </View>
          )}
        </View>

        {/* Credits Info */}
        <View style={styles.creditsInfo}>
          <Ionicons name="flash" size={18} color={COLORS.warning} />
          <Text style={styles.creditsText}>
            {credits} credit{credits !== 1 ? 's' : ''} remaining
          </Text>
          <TouchableOpacity onPress={() => router.push('/subscription')}>
            <Text style={styles.getMoreText}>Get more</Text>
          </TouchableOpacity>
        </View>

        {/* Action Buttons */}
        <View style={styles.actionButtons}>
          <Button
            title="Save Draft"
            onPress={handleSaveDraft}
            variant="outline"
            icon="document-text"
            style={{ flex: 1, marginRight: 8 }}
          />
          <Button
            title={isScheduling ? 'Schedule' : 'Post Now'}
            onPress={handlePost}
            variant="primary"
            icon={isScheduling ? 'calendar' : 'send'}
            style={{ flex: 1, marginLeft: 8 }}
          />
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: COLORS.text,
    marginBottom: 12,
  },
  mediaButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  mediaButton: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: COLORS.backgroundCard,
    borderRadius: SIZES.radius,
    padding: 24,
    marginHorizontal: 6,
    borderWidth: 1,
    borderColor: COLORS.border,
    borderStyle: 'dashed',
  },
  mediaButtonIcon: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: COLORS.backgroundInput,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  mediaButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: COLORS.text,
  },
  selectedImageContainer: {
    position: 'relative',
    borderRadius: SIZES.radius,
    overflow: 'hidden',
  },
  selectedImage: {
    width: '100%',
    height: 300,
    borderRadius: SIZES.radius,
  },
  removeImageButton: {
    position: 'absolute',
    top: 12,
    right: 12,
    backgroundColor: COLORS.white,
    borderRadius: 14,
  },
  hashtagToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
  },
  hashtagToggleText: {
    flex: 1,
    fontSize: 14,
    color: COLORS.primary,
    marginLeft: 8,
  },
  hashtagsContainer: {
    backgroundColor: COLORS.backgroundCard,
    borderRadius: SIZES.radius,
    padding: 16,
  },
  hashtagCategory: {
    marginBottom: 12,
  },
  hashtagCategoryTitle: {
    fontSize: 12,
    fontWeight: '600',
    color: COLORS.textMuted,
    marginBottom: 8,
    textTransform: 'uppercase',
  },
  hashtagsList: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  hashtagChip: {
    backgroundColor: COLORS.primary + '20',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    marginRight: 8,
    marginBottom: 8,
  },
  hashtagChipText: {
    fontSize: 13,
    color: COLORS.primary,
  },
  platformsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
  },
  platformCard: {
    width: '30%',
    alignItems: 'center',
    backgroundColor: COLORS.backgroundCard,
    borderRadius: SIZES.radius,
    padding: 16,
    marginRight: '5%',
    marginBottom: 12,
    borderWidth: 2,
    borderColor: COLORS.border,
    position: 'relative',
  },
  platformCardSelected: {
    borderColor: COLORS.primary,
  },
  platformIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  platformName: {
    fontSize: 12,
    color: COLORS.text,
    textAlign: 'center',
  },
  checkmark: {
    position: 'absolute',
    top: 8,
    right: 8,
  },
  connectPrompt: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.backgroundCard,
    borderRadius: SIZES.radius,
    padding: 16,
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  connectPromptText: {
    flex: 1,
    fontSize: 14,
    color: COLORS.text,
    marginLeft: 12,
  },
  scheduleToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: COLORS.backgroundCard,
    borderRadius: SIZES.radius,
    padding: 16,
  },
  scheduleToggleLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  scheduleToggleText: {
    fontSize: 16,
    color: COLORS.text,
    marginLeft: 12,
  },
  toggle: {
    width: 50,
    height: 28,
    borderRadius: 14,
    backgroundColor: COLORS.backgroundInput,
    padding: 2,
  },
  toggleActive: {
    backgroundColor: COLORS.primary,
  },
  toggleKnob: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: COLORS.white,
  },
  toggleKnobActive: {
    transform: [{ translateX: 22 }],
  },
  schedulePicker: {
    marginTop: 12,
    padding: 16,
    backgroundColor: COLORS.backgroundCard,
    borderRadius: SIZES.radius,
  },
  scheduleNote: {
    fontSize: 13,
    color: COLORS.textMuted,
    fontStyle: 'italic',
  },
  creditsInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    borderTopWidth: 1,
    borderTopColor: COLORS.border,
    marginBottom: 16,
  },
  creditsText: {
    fontSize: 14,
    color: COLORS.textSecondary,
    marginLeft: 8,
  },
  getMoreText: {
    fontSize: 14,
    fontWeight: '600',
    color: COLORS.primary,
    marginLeft: 12,
  },
  actionButtons: {
    flexDirection: 'row',
  },
});
